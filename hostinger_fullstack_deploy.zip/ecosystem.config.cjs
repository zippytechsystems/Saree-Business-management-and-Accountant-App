module.exports = {
  apps: [
    {
      name: 'saree-business-erp',
      script: 'backend/server.js',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production',
        PORT: process.env.PORT || 3000,
        CLOUD_BACKUP_PROVIDER: 'hostinger',
      },
    },
  ],
};
